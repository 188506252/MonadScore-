import json

# 从 wallet.txt 和 privateKey.txt 生成 accounts.json
def generate_accounts(wallet_file, privatekey_file, output_file="accounts.json"):
    # 读取钱包地址
    try:
        with open(wallet_file, 'r', encoding='utf-8') as wf:
            wallets = [line.strip() for line in wf if line.strip()]
    except FileNotFoundError:
        print(f"错误: 文件 {wallet_file} 不存在")
        return
    
    # 读取私钥
    try:
        with open(privatekey_file, 'r', encoding='utf-8') as pkf:
            private_keys = [line.strip() for line in pkf if line.strip()]
    except FileNotFoundError:
        print(f"错误: 文件 {privatekey_file} 不存在")
        return
    
    # 检查行数是否匹配
    if len(wallets) != len(private_keys):
        print(f"错误: {wallet_file} 有 {len(wallets)} 行, {privatekey_file} 有 {len(private_keys)} 行，数量不匹配")
        return
    
    # 组合成 accounts 格式
    accounts = []
    for wallet, private_key in zip(wallets, private_keys):
        accounts.append({
            "walletAddress": wallet,
            "privateKey": private_key
        })
    
    # 保存到 accounts.json
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(accounts, f, indent=2)
        print(f"已生成文件: {output_file}，共 {len(accounts)} 个账户")
    except Exception as e:
        print(f"保存文件时出错: {e}")

# 执行脚本
if __name__ == "__main__":
    wallet_file = "wallet.txt"         # 钱包地址文件
    privatekey_file = "privateKey.txt" # 私钥文件
    output_file = "accounts.json"      # 输出文件
    generate_accounts(wallet_file, privatekey_file, output_file)