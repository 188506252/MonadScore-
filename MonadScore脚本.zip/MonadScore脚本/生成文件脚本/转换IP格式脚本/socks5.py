# 读取 ip.txt 文件并将代理转换为 socks5://user:pass@host:port 格式
def convert_to_socks5(input_file, output_file):
    # 存储结果的列表
    result = []
    
    # 读取文件
    try:
        with open(input_file, 'r', encoding='utf-8') as file:
            for line in file:
                # 去除首尾空白字符
                proxy = line.strip()
                if proxy:  # 确保行不为空
                    # 按冒号分割，期望格式是 host:port:username:password
                    parts = proxy.split(':')
                    if len(parts) == 4:  # 确保有 4 个部分
                        host, port, username, password = parts
                        # 转换为 socks5://user:pass@host:port
                        socks5_proxy = f"socks5://{username}:{password}@{host}:{port}"
                        result.append(socks5_proxy)
                    else:
                        print(f"跳过格式错误的行: {proxy}")
        
        # 将结果写入新文件
        with open(output_file, 'w', encoding='utf-8') as output:
            output.write("\n".join(result))
        print(f"已生成文件: {output_file}")
    except FileNotFoundError:
        print(f"错误: 文件 {input_file} 不存在")
    except Exception as e:
        print(f"发生错误: {e}")

# 执行脚本
if __name__ == "__main__":
    input_file = "ip.txt"      # 输入文件
    output_file = "proxy.txt"  # 输出文件
    convert_to_socks5(input_file, output_file)