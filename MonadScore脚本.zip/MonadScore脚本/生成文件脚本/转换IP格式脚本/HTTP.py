# 读取 ip.txt 文件并在每行前添加 http://
def add_http_to_ips(input_file, output_file):
    # 存储结果的列表
    result = []
    
    # 读取文件
    with open(input_file, 'r') as file:
        # 逐行处理
        for line in file:
            # 去除首尾空白字符
            ip = line.strip()
            if ip:  # 确保行不为空
                # 在 IP 前添加 http://
                modified_ip = f"http://{ip}"
                result.append(modified_ip)
    
    # 将结果写入新文件
    with open(output_file, 'w') as output:
        output.write("\n".join(result))  # 每行用换行符分隔
    print(f"已生成文件: {output_file}")

# 执行脚本
if __name__ == "__main__":
    input_file = "ip.txt"  # 输入文件
    output_file = "proxies.txt"  # 输出文件
    add_http_to_ips(input_file, output_file)