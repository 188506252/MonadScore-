# MonadScoreBot-NTE
Monad Score Auto Run Node &amp; Auto Reff
Full Tutorial Join https://t.me/NTExhaust
